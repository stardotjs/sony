const express = require("express");
const config = require("./config.json");

let heroes = [];
let app = express();
// configurations / settings
app.set('views', __dirname+'/templates');
// middlewares
app.use(express.urlencoded({extended : true}));

app.get("/", (req, res) => {
    res.render("home.ejs",{ heroes });
});
app.post("/", (req, res) => {
    console.log("we got a post message", req.body)
    // res.render("home.ejs");
    heroes.push(req.body.nhero);
    res.redirect("/")
    // console.log(heroes);
});

app.listen(config.port, config.host, (err) => {
    if(err){ console.log("Error", err)}
    else{
        console.log("Express is now live on ",config.host, config.port)
    }
} )
