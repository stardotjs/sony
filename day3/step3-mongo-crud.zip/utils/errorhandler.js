module.exports = {
    errorHandler : (error) => {
        console.log("Error handler was called", error.code)
    }
}