const express = require("express");
const config = require("./config.json");
const herodata = require("./data/heros.json");
let app = express();

let users = ['Ironman','Thor','Hulk'];
app.get("/", function(req, res){
    // res.status(200).send("Hello from Express");
    // res.status(200).render("home.ejs");
    // res.status(200).render("home.ejs",{ users : herodata.list });
    res.status(200).render("home.pug",{ company : "Sony India",  users : herodata.list });
})

app.listen(config.port, config.host, (err)=>{
    if(err){
        console.log("Error", err)
    }else{
        console.log(`server is now live on ${config.host}:${config.port}`)
    }
})
