const express = require("express");
const config = require("./config.json");

let app = express();
app.get("/",function(req, res){
    /* 
    res.write("hello from express");
    res.end() 
    */
    res.status(200).send("hello from express");
})
app.listen(config.port,config.host);
console.log(`Server is now live on ${config.host}:${config.port}`);