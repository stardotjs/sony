const express = require("express");
const config = require("./config.json");

let app = express();
app.get("/",function(req, res){
    /* 
    res.write("hello from express");
    res.end() 
    */
    res.status(200).sendFile(__dirname+"/home.html");
})
app.get("/about",function(req, res){
    res.status(200).sendFile(__dirname+"/about.html");
})
app.get("/contact",function(req, res){
    res.status(200).sendFile(__dirname+"/contact.html");
})
app.get("**",function(req, res){
    res.status(200).sendFile(__dirname+"/404.html");
})
app.listen(config.port,config.host);
console.log(`Server is now live on ${config.host}:${config.port}`);