let mod = require("./step1");

console.log(mod.fullname());