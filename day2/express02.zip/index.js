const express = require("express");
let app = express();
app.use(express.static(__dirname+"/public"));
app.listen(3030,"localhost",err => err ? console.log("Error ", err) : console.log("localhost:3030"))