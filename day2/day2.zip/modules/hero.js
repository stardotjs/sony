import { Person } from "./person.js"
class Hero extends Person{
    // public
    title = "Default Title";
    firstname = "default firstname";
    lastname = "default lastname";
    static version = 101;
    // private
    #power = 0;
    constructor(ntitle, fname, lname, hcf){
        super(hcf)
        this.title = ntitle;
        this.firstname = fname;
        this.lastname = lname;
    }
    fullname(){
        return this.firstname+" "+this.lastname;
    }
    #showPower(){
        console.log(this.#power)
    }
    get power(){
        return this.#power;
    }
    set power(npower){
        this.#power = npower;
    }

};

export { Hero };