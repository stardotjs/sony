class Person{
    canFly = "default can fly";
    constructor(ncf){
        this.canFly = ncf;
    }
}

export { Person };